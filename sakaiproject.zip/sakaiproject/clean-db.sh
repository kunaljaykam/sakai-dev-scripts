# drop the database 'sakaidb' in mysql, if its exists
if [ -d /var/lib/mysql/sakaidb ]; then
    mysql -u root -proot -Bse "drop database sakaidb; create database sakaidb  default character set utf8; "
fi

if [ -d /home/kunaljaykam/sakaiproject/sakai-home/elasticsearch ]; then
    rm -rf /home/kunaljaykam/sakaiproject/sakai-home/elasticsearch
fi

if [ -d /home/kunaljaykam/sakaiproject/sakai-home/samigo ]; then
    rm -rf /home/kunaljaykam/sakaiproject/sakai-home/samigo
fi

if [ -d /home/kunaljaykam/sakaiproject/sakai-home/ignite ]; then
    rm -rf /home/kunaljaykam/sakaiproject/sakai-home/ignite
fi


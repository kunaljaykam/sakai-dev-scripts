cd /home/kunaljaykam/sakaiproject/apache-tomcat-9.0.64

bin/shutdown.sh;
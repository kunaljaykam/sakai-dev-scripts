# clean tomcat

if [ -d /home/kunaljaykam/sakaiproject/apache-tomcat-9.0.64 ]; then
    rm -rf /home/kunaljaykam/sakaiproject/apache-tomcat-9.0.64
fi

cd /home/kunaljaykam/sakaiproject

unzip /home/kunaljaykam/tomcat/apache-tomcat-9.0.64.zip

# make tomcat bin files executable
chmod -R +x /home/kunaljaykam/sakaiproject/apache-tomcat-9.0.64/bin/*
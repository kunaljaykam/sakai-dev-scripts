

cd /home/kunaljaykam/sakaiproject/apache-tomcat-9.0.64

bin/startup.sh; tail -f logs/catalina.out